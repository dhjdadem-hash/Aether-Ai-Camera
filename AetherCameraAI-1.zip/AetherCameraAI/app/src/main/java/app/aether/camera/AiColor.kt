package app.aether.camera

import android.content.ContentResolver
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** معالجة لون محلية بخوارزميات كلاسيكية (ليست شبكة عصبية): توازن أبيض + تمدد مستويات لطيف + منحنى + Vibrance. */
object AiColor {
    fun decode(cr: ContentResolver, uri: Uri, maxSide: Int = 4096): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (max(bounds.outWidth, bounds.outHeight) / s > maxSide) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val deg = cr.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        if (deg == 0) return bmp
        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
        bmp.recycle()
        return r
    }

    fun processFile(cr: ContentResolver, src: Uri, baseName: String): Uri? {
        val bmp = decode(cr, src) ?: return null
        val out = enhance(bmp)
        bmp.recycle()
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "${baseName}_AI.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AetherCamera")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        val ok = cr.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) } ?: false
        out.recycle()
        if (!ok) { cr.delete(uri, null, null); return null }
        cv.clear(); cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
        cr.update(uri, cv, null, null)
        return uri
    }

    fun enhance(src: Bitmap): Bitmap {
        val sw = 160
        val sh = (sw * src.height / src.width.toFloat()).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        small.recycle()
        var sr = 0.0; var sg = 0.0; var sb = 0.0; var cnt = 0
        val hist = IntArray(256)
        for (p in px) {
            val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
            val l = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            hist[l]++
            if (l in 16..239) { sr += r; sg += g; sb += b; cnt++ }
        }
        if (cnt < 50) cnt = 0
        val gray = if (cnt > 0) (sr + sg + sb) / (3.0 * cnt) else 1.0
        fun gain(m: Double): Float {
            if (cnt == 0 || m <= 0.0) return 1f
            val g = (gray / (m / cnt)).coerceIn(0.82, 1.22)
            return (1.0 + (g - 1.0) * 0.8).toFloat()
        }
        val gr = gain(sr); val gg = gain(sg); val gb = gain(sb)
        val total = px.size
        var acc = 0; var lo = 0; var hi = 255
        for (i in 0..255) { acc += hist[i]; if (acc >= total * 0.005) { lo = i; break } }
        acc = 0
        for (i in 255 downTo 0) { acc += hist[i]; if (acc >= total * 0.005) { hi = i; break } }
        lo = min(lo, 30); hi = max(hi, 215)
        val lut = IntArray(256) { v ->
            var x = ((v - lo).toFloat() / (hi - lo)).coerceIn(0f, 1f)
            x = x.toDouble().pow(0.95).toFloat()
            val s = x * x * (3 - 2 * x)
            ((x * 0.85f + s * 0.15f) * 255f).toInt().coerceIn(0, 255)
        }
        val w = src.width; val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val row = IntArray(w)
        for (y in 0 until h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                val p = row[x]
                var r = lut[(Color.red(p) * gr).toInt().coerceIn(0, 255)]
                var g = lut[(Color.green(p) * gg).toInt().coerceIn(0, 255)]
                var b = lut[(Color.blue(p) * gb).toInt().coerceIn(0, 255)]
                val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
                val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
                val k = 1f + 0.22f * (1f - sat)
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                r = (l + (r - l) * k).toInt().coerceIn(0, 255)
                g = (l + (g - l) * k).toInt().coerceIn(0, 255)
                b = (l + (b - l) * k).toInt().coerceIn(0, 255)
                row[x] = Color.rgb(r, g, b)
            }
            out.setPixels(row, 0, w, 0, y, w, 1)
        }
        return out
    }
}
