package app.aether.camera

import android.app.ActivityManager
import android.content.Context
import android.hardware.camera2.CameraCharacteristics as CC
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata as CM
import android.media.CamcorderProfile
import android.media.MediaRecorder
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.util.Locale
import kotlin.math.atan
import kotlin.math.hypot

fun f1(x: Number): String = String.format(Locale.US, "%.1f", x.toDouble())

data class Cam(
    val id: String, val facing: Int, val mp: Double, val focal: Float, val f35: Float, val fov: Float,
    val minZoom: Float, val maxZoom: Float, val phys: Set<String>,
    val mono: Boolean, val depth: Boolean, val minFocus: Float,
    val stab: Set<Int>, val ois: Set<Int>,
    val fps: List<Pair<Int, Int>>
)

sealed class Wide {
    data class Logical(val minZoom: Float) : Wide()
    data class Separate(val id: String, val ratio: Float) : Wide()
    data class None(val why: String) : Wide()
}

object CameraProbe {
    private fun mgr(c: Context) = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    fun scan(ctx: Context): List<Cam> {
        val m = mgr(ctx)
        return m.cameraIdList.mapNotNull { id ->
            try {
                val c = m.getCameraCharacteristics(id)
                val px = c.get(CC.SENSOR_INFO_PIXEL_ARRAY_SIZE)
                val ph = c.get(CC.SENSOR_INFO_PHYSICAL_SIZE)
                val f = c.get(CC.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f
                val diag = if (ph != null) hypot(ph.width.toDouble(), ph.height.toDouble()).toFloat() else 0f
                val f35 = if (diag > 0f) f * 43.27f / diag else 0f
                val fov = if (ph != null && f > 0f) Math.toDegrees(2 * atan(ph.width / (2.0 * f))).toFloat() else 0f
                val zr = if (Build.VERSION.SDK_INT >= 30) c.get(CC.CONTROL_ZOOM_RATIO_RANGE) else null
                val caps = c.get(CC.REQUEST_AVAILABLE_CAPABILITIES)?.toSet() ?: emptySet()
                val cfa = c.get(CC.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT)
                Cam(
                    id, c.get(CC.LENS_FACING) ?: -1,
                    if (px != null) px.width * px.height / 1e6 else 0.0, f, f35, fov,
                    zr?.lower ?: 1f,
                    zr?.upper ?: (c.get(CC.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f),
                    c.physicalCameraIds,
                    cfa == 5 || cfa == 6 || caps.contains(CM.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME),
                    caps.contains(CM.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT),
                    c.get(CC.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f,
                    c.get(CC.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.toSet() ?: emptySet(),
                    c.get(CC.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.toSet() ?: emptySet(),
                    c.get(CC.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.map { it.lower to it.upper } ?: emptyList()
                )
            } catch (e: Exception) {
                null
            }
        }
    }

    fun main(cams: List<Cam>): Cam? =
        cams.filter { it.facing == CC.LENS_FACING_BACK && !it.mono && !it.depth }.maxByOrNull { it.mp }

    /** أفضل كاميرا خلفية أخرى لاستخدامها عند 0.8x: عدسة واسعة إن وُجدت، وإلا أي كاميرا أخرى (حتى 2MP). */
    fun pickAux(cams: List<Cam>): Cam? {
        val m = main(cams) ?: return null
        val others = cams.filter { it.facing == CC.LENS_FACING_BACK && it.id != m.id }
        val wide = others.filter { !it.depth && it.f35 > 0f && m.f35 > 0f && it.f35 / m.f35 < 0.95f && it.mp >= 4.0 }.minByOrNull { it.f35 }
        return wide ?: others.filter { !it.depth }.maxByOrNull { it.mp } ?: others.maxByOrNull { it.mp }
    }

    fun findWide(cams: List<Cam>): Wide {
        val m = main(cams) ?: return Wide.None("لا توجد كاميرا خلفية.")
        if (m.minZoom <= 0.85f) return Wide.Logical(m.minZoom)
        val back = cams.filter { it.facing == CC.LENS_FACING_BACK && it.id != m.id }
        val cand = back.filter {
            !it.mono && !it.depth && it.mp >= 4.0 && it.f35 > 0f && m.f35 > 0f && it.f35 / m.f35 < 0.95f
        }.minByOrNull { it.f35 }
        if (cand != null) return Wide.Separate(cand.id, cand.f35 / m.f35)
        val small = back.filter { it.mp < 4.0 }.joinToString { "ID ${it.id} (${f1(it.mp)}MP)" }
        return Wide.None(
            "لا توجد عدسة واسعة حقيقية يكشفها النظام لتطبيقات الطرف الثالث. " +
                (if (small.isNotEmpty()) "الكاميرا الصغيرة ($small) ليست عدسة واسعة مؤكدة؛ يمكنك اختبارها من «تقرير قدرات الكاميرا». " else "") +
                "لن يُعرض القص الرقمي على أنه زاوية واسعة."
        )
    }

    private fun facing(f: Int) = when (f) {
        CC.LENS_FACING_BACK -> "خلفية"
        CC.LENS_FACING_FRONT -> "أمامية"
        else -> "خارجية"
    }

    private fun role(c: Cam, m: Cam?): String = when {
        c.facing == CC.LENS_FACING_FRONT -> "سيلفي"
        c.mono -> "أحادية اللون (استنتاج)"
        c.depth -> "عمق (استنتاج)"
        m == null || c.id == m.id -> "رئيسية (الأعلى دقة)"
        c.f35 > 0f && m.f35 > 0f && c.f35 / m.f35 < 0.95f -> "واسعة ×${f1(c.f35 / m.f35)} (استنتاج من البؤرة)"
        c.f35 > 0f && m.f35 > 0f && c.f35 / m.f35 > 1.5f -> "تقريب (استنتاج)"
        c.mp < 4.0 && c.minFocus > 8f -> "مرجّح ماكرو — يحتاج اختبار"
        c.mp < 4.0 -> "مساعدة (عمق/ماكرو؟) — يحتاج اختبار"
        else -> "غير محدد"
    }

    private fun yn(b: Boolean) = if (b) "✓" else "✗"

    fun report(ctx: Context): String {
        val cams = scan(ctx)
        val m = main(cams)
        val mg = mgr(ctx)
        val sb = StringBuilder()
        fun ln(s: String = "") { sb.append(s).append('\n') }
        ln("الجهاز: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        ln("الذاكرة: ${mi.totalMem shr 20}MB · المتاح الآن ${mi.availMem shr 20}MB")
        ln("التخزين الحر: ${StatFs(Environment.getDataDirectory().path).availableBytes shr 20}MB")
        ln()
        ln("== نتيجة 0.8x ==")
        ln(when (val w = findWide(cams)) {
            is Wide.Logical -> "عدسة حقيقية عبر zoomRatio (الحد الأدنى ${f1(w.minZoom)}x). يجب تأكيدها بصريًا من المعاينة."
            is Wide.Separate -> "عدسة واسعة منفصلة ID ${w.id} بنسبة ${f1(w.ratio)}x مقارنة بالرئيسية."
            is Wide.None -> w.why
        })
        cams.forEach { c ->
            ln()
            ln("== الكاميرا ID ${c.id} — ${facing(c.facing)} — ${role(c, m)} ==")
            ln("${f1(c.mp)}MP · بؤرة ${f1(c.focal)}mm (≈${f1(c.f35)}mm مكافئ) · مجال أفقي ≈${f1(c.fov)}°")
            ln("زوم ${f1(c.minZoom)}x–${f1(c.maxZoom)}x · فيزيائية: ${if (c.phys.isEmpty()) "—" else c.phys.joinToString()}")
            ln("أقرب تركيز: ${if (c.minFocus > 0f) f1(100f / c.minFocus) + "cm" else "ثابت/لانهائي"}")
            ln("تثبيت فيديو (modes): ${c.stab} · تثبيت بصري: ${c.ois}")
            try {
                val ch = mg.getCameraCharacteristics(c.id)
                val caps = ch.get(CC.REQUEST_AVAILABLE_CAPABILITIES)?.toSet() ?: emptySet()
                val iso = ch.get(CC.SENSOR_INFO_SENSITIVITY_RANGE)
                val ex = ch.get(CC.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                if (iso != null && ex != null) ln("ISO ${iso.lower}–${iso.upper} · غالق ${ex.lower / 1000}µs–${ex.upper / 1000000}ms")
                ln("فلاش ${yn(ch.get(CC.FLASH_INFO_AVAILABLE) == true)} · RAW ${yn(caps.contains(CM.REQUEST_AVAILABLE_CAPABILITIES_RAW))} · 10-bit ${yn(caps.contains(18))} · منطقية متعددة ${yn(caps.contains(CM.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA))}")
                ln("مستوى العتاد: " + arrayOf("LIMITED", "FULL", "LEGACY", "LEVEL_3", "EXTERNAL").getOrElse(ch.get(CC.INFO_SUPPORTED_HARDWARE_LEVEL) ?: -1) { "?" })
                val map = ch.get(CC.SCALER_STREAM_CONFIGURATION_MAP)
                val vs = map?.getOutputSizes(MediaRecorder::class.java)?.maxByOrNull { it.width.toLong() * it.height }
                val fps = ch.get(CC.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.maxOfOrNull { it.upper }
                ln("أكبر حجم فيديو: ${vs?.width}x${vs?.height} · fps حتى ${fps}")
                val idn = c.id.toIntOrNull()
                if (idn != null) {
                    val sbp = StringBuilder()
                    listOf("1080p" to CamcorderProfile.QUALITY_1080P, "4K" to CamcorderProfile.QUALITY_2160P, "8K" to CamcorderProfile.QUALITY_8KUHD)
                        .forEach { (n, q) ->
                            try {
                                if (CamcorderProfile.hasProfile(idn, q)) sbp.append("$n@${CamcorderProfile.get(idn, q)?.videoFrameRate}fps ")
                                else sbp.append("$n✗ ")
                            } catch (e: Exception) { sbp.append("$n? ") }
                        }
                    ln("ملفات الفيديو الرسمية: $sbp")
                }
                ln("ملاحظة: وجود دقة/معدل في القائمة لا يعني نجاح التسجيل؛ يجب اختبار التسجيل الفعلي.")
            } catch (e: Exception) {
                ln("تعذر قراءة بعض الخصائص: ${e.message}")
            }
        }
        return sb.toString()
    }
}
