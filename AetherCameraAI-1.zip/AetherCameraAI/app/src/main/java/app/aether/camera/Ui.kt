package app.aether.camera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** زجاج: تدرج علوي أفتح + حد شفاف. */
fun Context.glass(radiusDp: Int = 24, fill: Int = 0x33FFFFFF, stroke: Int = 0x66FFFFFF): GradientDrawable {
    val a = fill ushr 24
    val hi = (minOf(255, a + 0x1C) shl 24) or (fill and 0x00FFFFFF)
    return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(hi, fill)).apply {
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), stroke)
    }
}

fun Context.glassButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label
    setTextColor(Color.WHITE)
    textSize = 14f
    gravity = Gravity.CENTER
    minWidth = dp(44)
    minHeight = dp(44)
    setPadding(dp(12), dp(6), dp(12), dp(6))
    background = glass(22)
    setOnClickListener { v ->
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
        onClick()
    }
}

fun lp(w: Int = WRAP, h: Int = WRAP, m: Int = 0) =
    LinearLayout.LayoutParams(w, h).apply { setMargins(m, m, m, m) }

class GridOverlay(c: Context) : View(c) {
    private val p = Paint().apply { color = 0x66FFFFFF; strokeWidth = 2f }
    override fun onDraw(cv: Canvas) {
        for (i in 1..2) {
            val x = width * i / 3f
            val y = height * i / 3f
            cv.drawLine(x, 0f, x, height.toFloat(), p)
            cv.drawLine(0f, y, width.toFloat(), y, p)
        }
    }
}
