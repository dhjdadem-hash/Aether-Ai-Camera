package app.aether.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.view.WindowManager
import kotlin.math.max

class AutoFitTextureView(c: Context) : TextureView(c) {
    private var rw = 0
    private var rh = 0
    fun setAspect(w: Int, h: Int) { rw = w; rh = h; requestLayout() }
    override fun onMeasure(ws: Int, hs: Int) {
        super.onMeasure(ws, hs)
        val w = MeasureSpec.getSize(ws)
        val h = MeasureSpec.getSize(hs)
        if (rw == 0 || rh == 0) setMeasuredDimension(w, h)
        else if (w < h * rw / rh) setMeasuredDimension(w, w * rh / rw)
        else setMeasuredDimension(h * rw / rh, h)
    }
}

/**
 * مسار Camera2 مباشر لفتح أي Camera ID (مثل الكاميرا 2MP) حتى لو لم تقبله CameraX.
 * معاينة + صورة JPEG فقط (بدون فيديو/زوم).
 */
class Cam2(private val ctx: Context, private val tv: AutoFitTextureView, private val fail: (String) -> Unit) {
    private val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var dev: CameraDevice? = null
    private var sess: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var h: Handler? = null
    private var sensorOri = 90
    private var prev = Size(1280, 720)
    private var camId: String? = null
    private var afOk = false

    init {
        tv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> configureTransform() }
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, hh: Int) { if (camId != null && dev == null) startDevice() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, hh: Int) { configureTransform() }
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) { }
        }
    }

    private fun rotation(): Int = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
    private fun landscape(): Boolean { val r = rotation(); return r == Surface.ROTATION_90 || r == Surface.ROTATION_270 }
    private fun applyAspect() { if (landscape()) tv.setAspect(prev.width, prev.height) else tv.setAspect(prev.height, prev.width) }
    fun onRotation() { applyAspect(); configureTransform() }

    fun open(id: String) {
        close()
        camId = id
        try {
            val ch = mgr.getCameraCharacteristics(id)
            sensorOri = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            afOk = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE) == true
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
            val jpeg = map.getOutputSizes(ImageFormat.JPEG).maxByOrNull { it.width.toLong() * it.height }!!
            val sizes = map.getOutputSizes(SurfaceTexture::class.java)
            prev = sizes.filter { it.width <= 1920 && it.height <= 1080 && it.width * jpeg.height == it.height * jpeg.width }
                .maxByOrNull { it.width * it.height }
                ?: sizes.filter { it.width <= 1920 && it.height <= 1080 }.maxByOrNull { it.width * it.height }
                ?: sizes.first()
            applyAspect()
            thread = HandlerThread("cam2").also { it.start() }
            h = Handler(thread!!.looper)
            reader = ImageReader.newInstance(jpeg.width, jpeg.height, ImageFormat.JPEG, 2)
            if (tv.isAvailable) startDevice()
        } catch (e: Exception) {
            fail("Camera2 open failed (ID $id): ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun startDevice() {
        val id = camId ?: return
        val st = tv.surfaceTexture ?: return
        st.setDefaultBufferSize(prev.width, prev.height)
        val surface = Surface(st)
        configureTransform()
        try {
            mgr.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    dev = d
                    try {
                        d.createCaptureSession(listOf(surface, reader!!.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                sess = s
                                try {
                                    val rb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                    rb.addTarget(surface)
                                    if (afOk) rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                    s.setRepeatingRequest(rb.build(), null, h)
                                } catch (e: Exception) { fail("Preview failed: ${e.message}") }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { fail("This lens (ID $id) can't be used for preview + photo.") }
                        }, h)
                    } catch (e: Exception) { fail("Session failed: ${e.message}") }
                }
                override fun onDisconnected(d: CameraDevice) { d.close(); dev = null }
                override fun onError(d: CameraDevice, error: Int) { d.close(); dev = null; fail("Camera ID $id error code $error") }
            }, h)
        } catch (e: Exception) {
            fail("Can't open camera $id: ${e.message}")
        }
    }

    fun capture(devOri: Int, onJpeg: (ByteArray) -> Unit) {
        val d = dev
        val s = sess
        val r = reader
        if (d == null || s == null || r == null) { fail("Camera isn't ready yet"); return }
        r.setOnImageAvailableListener(object : ImageReader.OnImageAvailableListener {
            override fun onImageAvailable(rd: ImageReader) {
                val img = rd.acquireLatestImage() ?: return
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    onJpeg(bytes)
                } finally { img.close() }
            }
        }, h)
        try {
            val rb = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            rb.addTarget(r.surface)
            if (afOk) rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            val o = (devOri + 45) / 90 * 90 % 360
            rb.set(CaptureRequest.JPEG_ORIENTATION, (sensorOri - o + 360) % 360)
            rb.set(CaptureRequest.JPEG_QUALITY, 95.toByte())
            s.capture(rb.build(), null, h)
        } catch (e: Exception) { fail("Capture failed: ${e.message}") }
    }

    fun configureTransform() {
        val vw = tv.width.toFloat()
        val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val rot = rotation()
        val m = Matrix()
        val viewRect = RectF(0f, 0f, vw, vh)
        val bufRect = RectF(0f, 0f, prev.height.toFloat(), prev.width.toFloat())
        val cx = viewRect.centerX()
        val cy = viewRect.centerY()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            bufRect.offset(cx - bufRect.centerX(), cy - bufRect.centerY())
            m.setRectToRect(viewRect, bufRect, Matrix.ScaleToFit.FILL)
            val sc = max(vh / prev.height, vw / prev.width)
            m.postScale(sc, sc, cx, cy)
            m.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) {
            m.postRotate(180f, cx, cy)
        }
        tv.setTransform(m)
    }

    fun close() {
        try { sess?.close() } catch (e: Exception) { }
        try { dev?.close() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        sess = null; dev = null; reader = null; camId = null
        thread?.quitSafely(); thread = null; h = null
    }
}
