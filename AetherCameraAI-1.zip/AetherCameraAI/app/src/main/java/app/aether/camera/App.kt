package app.aether.camera

import android.app.Application
import android.util.Log
import java.io.File

/** يحفظ نص أي انهيار ليعرضه التطبيق عند الفتح التالي (بدون حاجة لأدوات مطورين). */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(e)) } catch (x: Exception) { }
            prev?.uncaughtException(t, e)
        }
    }
}
