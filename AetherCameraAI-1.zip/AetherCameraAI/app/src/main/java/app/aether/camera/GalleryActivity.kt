package app.aether.camera

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.util.concurrent.Executors
import kotlin.math.min

class SquareImageView(c: Context) : ImageView(c) {
    override fun onMeasure(w: Int, h: Int) { super.onMeasure(w, w) }
}

/** يرسم "بعد" كاملًا و"قبل" مقصوصًا حتى موضع الشريط؛ اسحب للمقارنة. */
class CompareView(c: Context) : View(c) {
    var before: Bitmap? = null
    var after: Bitmap? = null
    private var split = 0.5f
    private val p = Paint(Paint.FILTER_BITMAP_FLAG)
    private val lp = Paint().apply { color = Color.WHITE; strokeWidth = 4f }
    private val tp = Paint().apply { color = Color.WHITE; textSize = 36f; setShadowLayer(4f, 0f, 0f, Color.BLACK) }

    override fun onDraw(c: Canvas) {
        val a = after ?: before ?: return
        val dst = fit(a)
        c.drawBitmap(a, null, dst, p)
        val b = before
        if (b != null && after != null) {
            val sx = width * split
            c.save(); c.clipRect(0f, 0f, sx, height.toFloat()); c.drawBitmap(b, null, dst, p); c.restore()
            c.drawLine(sx, 0f, sx, height.toFloat(), lp)
            c.drawText("Original", 24f, 120f, tp)
            c.drawText("AI", width - 90f, 120f, tp)
        }
    }

    private fun fit(b: Bitmap): RectF {
        val s = min(width / b.width.toFloat(), height / b.height.toFloat())
        val w = b.width * s; val h = b.height * s
        return RectF((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        split = (e.x / width).coerceIn(0f, 1f); invalidate(); return true
    }
}

class GalleryActivity : ComponentActivity() {
    private data class Item(val uri: Uri, val name: String, val video: Boolean)

    private var items = listOf<Item>()
    private val exec = Executors.newFixedThreadPool(3)
    private val cache = LruCache<Uri, Bitmap>(80)
    private lateinit var root: FrameLayout
    private lateinit var grid: GridView
    private var viewer: View? = null
    private val back = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { closeViewer() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, back)
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(2); verticalSpacing = dp(2)
            setOnItemClickListener { _, _, pos, _ -> open(items[pos]) }
        }
        root.addView(grid, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        val out = mutableListOf<Item>()
        val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.MEDIA_TYPE)
        val sel = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? AND ${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (?, ?)"
        val args = arrayOf(
            "%AetherCamera%",
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
        )
        contentResolver.query(MediaStore.Files.getContentUri("external"), proj, sel, args, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val vid = c.getInt(2) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val base = if (vid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                out += Item(ContentUris.withAppendedId(base, id), c.getString(1) ?: "", vid)
            }
        }
        items = out
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val iv = (cv as? SquareImageView) ?: SquareImageView(this@GalleryActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(0xFF222222.toInt())
                }
                val item = items[pos]
                iv.tag = item.uri
                val cached = cache.get(item.uri)
                iv.setImageBitmap(cached)
                if (cached == null) exec.execute {
                    try {
                        val b = contentResolver.loadThumbnail(item.uri, Size(256, 256), null)
                        cache.put(item.uri, b)
                        runOnUiThread { if (iv.tag == item.uri) iv.setImageBitmap(b) }
                    } catch (e: Exception) { }
                }
                return iv
            }
        }
        if (items.isEmpty()) Toast.makeText(this, "No files yet", Toast.LENGTH_SHORT).show()
    }

    private fun open(item: Item) {
        if (item.video) {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(item.uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            return
        }
        val base = item.name.removeSuffix("_AI.jpg").removeSuffix(".jpg")
        val orig = items.find { it.name == "$base.jpg" }
        val ai = items.find { it.name == "${base}_AI.jpg" }
        val cv = CompareView(this)
        val v = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        v.addView(cv, FrameLayout.LayoutParams(MATCH, MATCH))
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        bar.addView(glassButton("✕") { closeViewer() }, lp(m = dp(4)))
        bar.addView(glassButton("Share") {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM, item.uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
        }, lp(m = dp(4)))
        bar.addView(glassButton("Delete") {
            try {
                contentResolver.delete(item.uri, null, null)
                closeViewer(); load()
            } catch (e: Exception) {
                Toast.makeText(this, "Delete failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, lp(m = dp(4)))
        v.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        viewer = v
        back.isEnabled = true
        exec.execute {
            val b = orig?.let { AiColor.decode(contentResolver, it.uri, 2048) }
            val a = ai?.let { AiColor.decode(contentResolver, it.uri, 2048) }
            runOnUiThread {
                cv.before = if (b != null && a != null) b else null
                cv.after = a ?: b
                cv.invalidate()
            }
        }
    }

    private fun closeViewer() {
        viewer?.let { root.removeView(it) }
        viewer = null
        back.isEnabled = false
    }
}
