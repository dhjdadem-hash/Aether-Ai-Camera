package app.aether.camera

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.sqrt

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : ComponentActivity() {
    private data class Stop(val label: String, val id: String?, val zoom: Float)

    private lateinit var stage: FrameLayout
    private lateinit var preview: PreviewView
    private lateinit var tex: AutoFitTextureView
    private lateinit var grid: GridOverlay
    private lateinit var zoomLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var countText: TextView
    private lateinit var flashBtn: TextView
    private lateinit var aiBtn: TextView
    private lateinit var modePhoto: TextView
    private lateinit var modeVideo: TextView
    private lateinit var thumb: ImageView
    private lateinit var shutterInner: View
    private lateinit var chipRow: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var orient: OrientationEventListener
    private lateinit var cam2: Cam2

    private val exec = Executors.newSingleThreadExecutor()
    private val chipViews = mutableListOf<TextView>()
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var cams = listOf<Cam>()
    private var main: Cam? = null
    private var aux: Cam? = null
    private var stops = listOf<Stop>()
    private var currentId: String? = null
    private var front = false
    private var videoMode = false
    private var cam2Active = false
    private var aiOn = true
    private var stab = 1
    private var flash = ImageCapture.FLASH_MODE_OFF
    private var quality: Quality = Quality.HIGHEST
    private var fps = 30
    private var micOn = true
    private var timerSec = 0
    private var devOri = 0
    private val notified = mutableSetOf<String>()
    private val triedCam2 = mutableSetOf<String>()
    @Volatile private var appliedStab = -1
    @Volatile private var appliedOis = -1

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasPerm(Manifest.permission.CAMERA)) startCamera() else toast("Camera permission is required", true)
    }

    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String, long: Boolean = false) =
        Toast.makeText(this, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            cams = CameraProbe.scan(this)
            main = CameraProbe.main(cams)
            aux = CameraProbe.pickAux(cams)
        } catch (e: Exception) { }
        currentId = main?.id
        buildUi()
        buildStops()
        cam2 = Cam2(this, tex) { msg -> runOnUiThread { toast(msg, true); fallbackMain() } }
        orient = object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                devOri = o
                val r = when (o) {
                    in 45..134 -> android.view.Surface.ROTATION_270
                    in 135..224 -> android.view.Surface.ROTATION_180
                    in 225..314 -> android.view.Surface.ROTATION_90
                    else -> android.view.Surface.ROTATION_0
                }
                imageCapture?.targetRotation = r
                videoCapture?.targetRotation = r
            }
        }
        showCrashIfAny()
        permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    override fun onStart() {
        super.onStart()
        orient.enable()
        if (cam2Active) currentId?.let { cam2.open(it) }
    }

    override fun onStop() {
        super.onStop()
        orient.disable()
        recording?.stop()
        cam2.close()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (cam2Active) cam2.onRotation()
    }

    override fun onResume() {
        super.onResume()
        val p = getSharedPreferences("aether", MODE_PRIVATE)
        val id = p.getString("force", null)
        if (id != null) {
            p.edit().remove("force").apply()
            front = false
            currentId = id
            if (provider != null) forceOpen(id)
        }
    }

    private fun showCrashIfAny() {
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) return
        val t = f.readText()
        f.delete()
        AlertDialog.Builder(this)
            .setTitle("The app closed unexpectedly last time")
            .setMessage(t.take(2500))
            .setPositiveButton("Copy") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("crash", t))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------------------------------------------------------------- UI
    private fun fmt(v: Float) = if (v == v.toInt().toFloat()) "${v.toInt()}" else f1(v)

    private fun styleChip(t: TextView, on: Boolean) {
        t.background = if (on) glass(22, 0xFFD6D9FF.toInt(), 0xFFD6D9FF.toInt()) else glass(22)
        t.setTextColor(if (on) Color.parseColor("#0B1030") else Color.WHITE)
    }

    private fun chip(label: String, on: Boolean, click: () -> Unit): TextView =
        glassButton(label, click).also { styleChip(it, on) }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = FrameLayout(this)
        preview = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
        tex = AutoFitTextureView(this).apply { visibility = View.GONE }
        grid = GridOverlay(this).apply { visibility = View.GONE }
        stage.addView(preview, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(tex, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        stage.addView(grid, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(stage, FrameLayout.LayoutParams(MATCH, MATCH))

        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (cam2Active) return false
                val cur = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: return false
                setZoom(cur * d.scaleFactor)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean { focusAt(e.x, e.y); return true }
        })
        stage.setOnTouchListener { _, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) tap.onTouchEvent(ev)
            true
        }

        flashBtn = glassButton("⚡ Off") { cycleFlash() }
        aiBtn = glassButton("AI ✓") { aiOn = !aiOn; aiBtn.text = if (aiOn) "AI ✓" else "AI ✕"; if (panel.visibility == View.VISIBLE) rebuildPanel() }
        val gear = glassButton("⚙") { togglePanel() }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        top.addView(flashBtn, lp(m = dp(3)))
        top.addView(aiBtn, lp(m = dp(3)))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(gear, lp(m = dp(3)))
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = glass(24, 0xE61A1B26.toInt(), 0x33FFFFFF)
            visibility = View.GONE
        }
        root.addView(panel, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { setMargins(dp(12), dp(64), dp(12), 0) })

        countText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 80f; gravity = Gravity.CENTER }
        root.addView(countText, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))

        statusLabel = TextView(this).apply { setTextColor(Color.parseColor("#C8CBF0")); textSize = 12f; gravity = Gravity.CENTER }
        zoomLabel = TextView(this).apply { setTextColor(Color.parseColor("#FFC107")); textSize = 14f; gravity = Gravity.CENTER }
        chipRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }

        modePhoto = glassButton("PHOTO") { setMode(false) }
        modeVideo = glassButton("VIDEO") { setMode(true) }
        val modes = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(modePhoto, lp(m = dp(4)))
            addView(modeVideo, lp(m = dp(4)))
        }

        val flip = glassButton("🔄") {
            if (recording != null) toast("Stop recording first") else {
                front = !front
                currentId = if (front) null else main?.id
                if (!bindX(currentId, 1f)) toast("Camera unavailable", true)
            }
        }
        flip.background = glass(26)
        thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = glass(26)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            setOnClickListener { startActivity(Intent(this@MainActivity, GalleryActivity::class.java)) }
        }
        val ring = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(4), Color.WHITE) }
        }
        shutterInner = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        }
        val shutter = FrameLayout(this).apply {
            addView(ring, FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER))
            addView(shutterInner, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER))
            setOnClickListener { if (videoMode) toggleRecord() else shoot() }
        }
        val ctl = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(flip, lp(dp(52), dp(52), dp(26)))
            addView(shutter, lp(dp(80), dp(80), dp(20)))
            addView(thumb, lp(dp(52), dp(52), dp(26)))
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(12))
            background = glass(28, 0x55000000, 0x33FFFFFF)
            listOf<View>(statusLabel, zoomLabel, chipScroll, modes, ctl).forEach {
                addView(it, lp().apply { setMargins(0, dp(3), 0, dp(3)) })
            }
        }
        root.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(8), 0, dp(8), dp(8)) })
        setContentView(root)
        styleMode()
    }

    private fun styleMode() {
        styleChip(modePhoto, !videoMode)
        styleChip(modeVideo, videoMode)
        (shutterInner.background as GradientDrawable).setColor(if (videoMode) Color.parseColor("#FF3B30") else Color.WHITE)
    }

    private fun addRow(title: String, opts: List<String>, sel: Int, pick: (Int) -> Unit) {
        panel.addView(TextView(this).apply {
            text = title; setTextColor(Color.parseColor("#B8BCE8")); textSize = 12f
        }, lp().apply { setMargins(0, dp(6), 0, dp(2)) })
        val r = LinearLayout(this)
        opts.forEachIndexed { i, o -> r.addView(chip(o, i == sel) { pick(i) }, lp(m = dp(3))) }
        panel.addView(r)
    }

    private fun rebuildPanel() {
        panel.removeAllViews()
        if (videoMode) {
            addRow("Resolution", listOf("FHD", "4K", "8K"), when (quality) { Quality.FHD -> 0; Quality.UHD -> 1; else -> -1 }) { i ->
                when (i) {
                    0 -> setQuality(Quality.FHD)
                    1 -> setQuality(Quality.UHD)
                    else -> toast("8K isn't available in this version. Real options: 4K / FHD.", true)
                }
            }
            addRow("Frame rate (camera target)", listOf("24", "30", "60"), when (fps) { 24 -> 0; 30 -> 1; else -> 2 }) { i ->
                fps = intArrayOf(24, 30, 60)[i]
                if (pickFps(curCam(), fps) == null) toast("This camera doesn't list ${fps}fps; default will be used", true)
                rebind(); rebuildPanel()
            }
            addRow("Stabilization", listOf("Off", "Standard", "Active"), stab) { i -> setStab(i) }
            addRow("Microphone", listOf("On", "Off"), if (micOn) 0 else 1) { i -> micOn = i == 0; rebuildPanel() }
        } else {
            addRow("AI Color (saves a separate _AI copy)", listOf("On", "Off"), if (aiOn) 0 else 1) { i ->
                aiOn = i == 0; aiBtn.text = if (aiOn) "AI ✓" else "AI ✕"; rebuildPanel()
            }
            addRow("Timer", listOf("Off", "3s", "10s"), when (timerSec) { 0 -> 0; 3 -> 1; else -> 2 }) { i ->
                timerSec = intArrayOf(0, 3, 10)[i]; rebuildPanel()
            }
            addRow("Grid", listOf("Off", "On"), if (grid.visibility == View.VISIBLE) 1 else 0) { i ->
                grid.visibility = if (i == 1) View.VISIBLE else View.GONE; rebuildPanel()
            }
        }
        val info = glassButton("Camera info") { startActivity(Intent(this, ReportActivity::class.java)) }
        panel.addView(info, lp().apply { setMargins(0, dp(10), 0, 0) })
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.animate().alpha(0f).translationY(-dp(16).toFloat()).setDuration(160)
                .withEndAction { panel.visibility = View.GONE }.start()
        } else {
            rebuildPanel()
            panel.alpha = 0f
            panel.translationY = -dp(16).toFloat()
            panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).translationY(0f).setDuration(200).start()
        }
    }

    private fun buildStops() {
        val m = main
        val a = aux
        val s = mutableListOf<Stop>()
        if (m != null && m.minZoom <= 0.85f) {
            if (m.minZoom < 0.79f) { s += Stop(fmt(m.minZoom), m.id, m.minZoom) }
            s += Stop("0.8", m.id, 0.8f)
        } else if (a != null) {
            val r = if (m != null && m.f35 > 0f && a.f35 > 0f) a.f35 / m.f35 else 1f
            s += Stop("0.8", a.id, if (r < 0.8f) 0.8f / r else 1f)
        }
        s += Stop("1", m?.id, 1f)
        for (z in listOf(2f, 5f, 10f, 20f, 50f, 120f)) {
            if (m == null || z <= m.maxZoom) { s += Stop(fmt(z), m?.id, z) }
        }
        stops = s
        chipRow.removeAllViews()
        chipViews.clear()
        s.forEachIndexed { i, st ->
            val c = glassButton(st.label + "x") { applyStop(i) }
            chipViews += c
            chipRow.addView(c, lp(m = dp(3)))
        }
        selectChip(s.indexOfFirst { it.label == "1" })
    }

    private fun selectChip(i: Int) { chipViews.forEachIndexed { k, v -> styleChip(v, k == i) } }

    // ---------------------------------------------------------------- Camera (CameraX)
    private fun curCam() = cams.find { it.id == currentId }
    private fun curZoom() = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            if (!bindX(currentId, 1f)) toast("Couldn't open the camera", true)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun selectorFor(id: String?): CameraSelector {
        if (front) return CameraSelector.DEFAULT_FRONT_CAMERA
        if (id == null) return CameraSelector.DEFAULT_BACK_CAMERA
        return CameraSelector.Builder()
            .addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == id } }
            .build()
    }

    private fun <T> camOpts(e: Camera2Interop.Extender<T>, mode: Int, ois: Int, r: Pair<Int, Int>?) {
        e.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, mode)
        e.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, ois)
        if (r != null) e.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(r.first, r.second))
    }

    private fun pickFps(c: Cam?, f: Int): Pair<Int, Int>? =
        c?.fps?.find { it.first == f && it.second == f } ?: c?.fps?.filter { it.second == f }?.maxByOrNull { it.first }

    /** يربط CameraX؛ يرجع false عند الفشل (دون أي تراجع تلقائي). */
    private fun bindX(id: String?, zoom: Float): Boolean {
        val p = provider ?: return false
        if (recording != null) return false
        cam2.close()
        cam2Active = false
        tex.visibility = View.GONE
        preview.visibility = View.VISIBLE
        p.unbindAll()
        val pb = Preview.Builder()
        var ic: ImageCapture? = null
        var vc: VideoCapture<Recorder>? = null
        if (videoMode) {
            val rec = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                .build()
            val vb = VideoCapture.Builder(rec)
            val c = cams.find { it.id == id }
            val mode = when {
                stab == 0 -> CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
                stab == 2 && c?.stab?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION) == true ->
                    CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
                c?.stab?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true ->
                    CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
                else -> CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
            }
            val ois = if (stab > 0 && c?.ois?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true)
                CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON else CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF
            val range = pickFps(c, fps)
            camOpts(Camera2Interop.Extender(pb), mode, ois, range)
            camOpts(Camera2Interop.Extender(vb), mode, ois, range)
            Camera2Interop.Extender(pb).setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                    appliedStab = res.get(CaptureResult.CONTROL_VIDEO_STABILIZATION_MODE) ?: -1
                    appliedOis = res.get(CaptureResult.LENS_OPTICAL_STABILIZATION_MODE) ?: -1
                }
            })
            vc = vb.build()
        } else {
            ic = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(flash)
                .build()
        }
        val pv = pb.build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        try {
            camera = p.bindToLifecycle(this, selectorFor(id), *listOfNotNull<UseCase>(pv, ic, vc).toTypedArray())
        } catch (e: Exception) {
            camera = null
            return false
        }
        imageCapture = ic
        videoCapture = vc
        if (camera?.cameraInfo?.hasFlashUnit() == true) {
            camera?.cameraControl?.enableTorch(videoMode && flash == ImageCapture.FLASH_MODE_ON)
        }
        setZoom(zoom)
        updateStatus()
        return true
    }

    private fun rebind() {
        if (cam2Active) return
        if (!bindX(currentId, curZoom())) fallbackMain()
    }

    private fun openCam2(id: String) {
        if (!hasPerm(Manifest.permission.CAMERA)) return
        provider?.unbindAll()
        camera = null; imageCapture = null; videoCapture = null
        preview.visibility = View.GONE
        tex.visibility = View.VISIBLE
        cam2Active = true
        currentId = id
        cam2.open(id)
        notifyAux(id)
        zoomLabel.text = "0.8x · lens ID $id · photo only"
        updateStatus()
        postVerify()
    }

    private fun fallbackMain() {
        cam2.close()
        cam2Active = false
        front = false
        currentId = main?.id
        selectChip(stops.indexOfFirst { it.label == "1" })
        if (!bindX(currentId, 1f)) toast("Camera unavailable", true)
    }

    private fun forceOpen(id: String) {
        if (!bindX(id, 1f)) openCam2(id) else { notifyAux(id); postVerify() }
    }

    private fun applyStop(i: Int) {
        val st = stops[i]
        if (front) { toast("Lens switching works on the rear camera"); return }
        val id = st.id ?: currentId
        if (recording != null && id != currentId) { toast("Stop recording first"); return }
        selectChip(i)
        val isAux = id != null && id == aux?.id && id != main?.id
        if (id != currentId || cam2Active) {
            currentId = id
            if (!bindX(id, st.zoom)) {
                if (isAux && !videoMode && id != null) openCam2(id) else { toast("Couldn't open that lens", true); fallbackMain() }
            } else {
                if (isAux && id != null) notifyAux(id)
                postVerify()
            }
        } else {
            setZoom(st.zoom)
            if (st.zoom < 1f) postVerify()
        }
    }

    private fun notifyAux(id: String) {
        if (id == main?.id || !notified.add(id)) return
        val c = cams.find { it.id == id } ?: return
        val m = main
        val r = if (m != null && m.f35 > 0f && c.f35 > 0f) f1(c.f35 / m.f35) else "?"
        toast("0.8x uses lens ID $id · ${f1(c.mp)}MP · field of view ≈ ${r}x of the main camera", true)
    }

    private fun postVerify() { stage.postDelayed({ verify() }, 1600) }

    private fun verify() {
        val bmp: Bitmap = (if (cam2Active) tex.bitmap else preview.bitmap) ?: return
        val s = Bitmap.createScaledBitmap(bmp, 32, 32, true)
        var sum = 0.0
        var sq = 0.0
        var chroma = 0.0
        for (y in 0 until 32) for (x in 0 until 32) {
            val p = s.getPixel(x, y)
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val l = r * 0.299 + g * 0.587 + b * 0.114
            sum += l
            sq += l * l
            chroma += Math.abs(r - g) + Math.abs(g - b)
        }
        val mean = sum / 1024.0
        val sd = sqrt((sq / 1024.0 - mean * mean).coerceAtLeast(0.0))
        val chromaAvg = chroma / 1024.0
        val id = currentId
        if (mean < 6 || sd < 2.5) {
            if (!cam2Active && id != null && id == aux?.id && !videoMode && triedCam2.add(id)) openCam2(id)
            else { toast("This lens shows a black/empty preview. Back to the main camera.", true); fallbackMain() }
        } else if (chromaAvg < 3.0 && id != null && id != main?.id) {
            toast("This lens outputs black & white. If it's a monochrome sensor, real color isn't possible from it.", true)
        }
    }

    private fun setZoom(z: Float) {
        val cam = camera ?: return
        val st = cam.cameraInfo.zoomState.value
        val zz = if (st != null) z.coerceIn(st.minZoomRatio, st.maxZoomRatio) else z
        cam.cameraControl.setZoomRatio(zz)
        showZoom(zz)
        if (z > zz + 0.05f) toast("This device's max zoom is ${f1(zz)}x")
    }

    private fun showZoom(z: Float) {
        val m = main
        val t = cams.filter { it.facing == CameraCharacteristics.LENS_FACING_BACK }.maxOfOrNull { it.f35 } ?: 0f
        val tele = if (m != null && m.f35 > 0f && t > 0f) t / m.f35 else 1f
        val kind = when {
            z < 0.99f -> "wide"
            z <= 1.01f -> ""
            tele >= 1.5f && z <= tele -> "optical/hybrid"
            z > 10f -> "digital · very low quality (estimated detail)"
            z > 4f -> "digital · quality drops"
            else -> "digital (crop)"
        }
        zoomLabel.text = f1(z) + "x" + if (kind.isNotEmpty()) " · $kind" else ""
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val pt = preview.meteringPointFactory.createPoint(x, y)
        cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
    }

    private fun setMode(video: Boolean) {
        if (recording != null || video == videoMode) return
        videoMode = video
        styleMode()
        if (panel.visibility == View.VISIBLE) rebuildPanel()
        if (cam2Active) {
            if (video) { toast("Video isn't available on this lens. Using the main camera.", true); fallbackMain() }
        } else if (!bindX(currentId, curZoom())) fallbackMain()
    }

    private fun cycleFlash() {
        if (cam2Active) { toast("Flash isn't available on this lens"); return }
        if (camera?.cameraInfo?.hasFlashUnit() != true) { toast("This camera has no flash unit"); return }
        flash = when (flash) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flash
        camera?.cameraControl?.enableTorch(videoMode && flash == ImageCapture.FLASH_MODE_ON)
        flashBtn.text = when (flash) {
            ImageCapture.FLASH_MODE_AUTO -> "⚡ Auto"
            ImageCapture.FLASH_MODE_ON -> if (videoMode) "⚡ Torch" else "⚡ On"
            else -> "⚡ Off"
        }
    }

    private fun setStab(i: Int) {
        if (recording != null) { toast("Can't change stabilization while recording"); return }
        val c = curCam()
        var n = i
        if (n == 2 && c?.stab?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION) != true) {
            toast("Active (preview stabilization) isn't supported by this camera", true)
            n = if (c?.stab?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true) 1 else 0
        }
        if (n == 1 && c?.stab?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) != true &&
            c?.ois?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) != true) {
            toast("This camera has no stabilization", true)
            n = 0
        }
        stab = n
        rebind()
        rebuildPanel()
    }

    private fun setQuality(q: Quality) {
        if (recording != null) { toast("Can't change resolution while recording"); return }
        val info = camera?.cameraInfo
        if (info != null && !QualitySelector.isQualitySupported(info, q)) { toast("This resolution isn't supported by this camera", true); return }
        quality = q
        rebind()
        rebuildPanel()
    }

    private fun updateStatus() {
        val free = StatFs(Environment.getDataDirectory().path).availableBytes shr 20
        val base = "Lens ${if (front) "front" else currentId} · ${free} MB free"
        statusLabel.text = base
        if (videoMode) statusLabel.postDelayed({
            if (recording == null) statusLabel.text = "$base · stabilization applied: $appliedStab / optical $appliedOis"
        }, 1500)
    }

    // ---------------------------------------------------------------- Photo
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun shoot() {
        if (timerSec == 0) { takePhoto(); return }
        var n = timerSec
        val hd = Handler(Looper.getMainLooper())
        val r = object : Runnable {
            override fun run() {
                if (n > 0) { countText.text = "$n"; n--; hd.postDelayed(this, 1000) }
                else { countText.text = ""; takePhoto() }
            }
        }
        r.run()
    }

    private fun takePhoto() {
        val name = "AETHER_" + stamp()
        if (cam2Active) {
            cam2.capture(devOri) { bytes ->
                exec.execute {
                    val uri = try { saveJpeg(bytes, name) } catch (e: Exception) { null }
                    runOnUiThread { if (uri != null) afterSaved(uri, name) else toast("Save failed", true) }
                }
            }
            return
        }
        val ic = imageCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AetherCamera")
        }
        val opts = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        ic.takePicture(opts, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                val uri = r.savedUri ?: return
                afterSaved(uri, name)
            }
            override fun onError(e: ImageCaptureException) { toast("Capture failed: ${e.message}", true) }
        })
    }

    private fun saveJpeg(bytes: ByteArray, name: String): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AetherCamera")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        val os = contentResolver.openOutputStream(uri)
        if (os == null) { contentResolver.delete(uri, null, null); return null }
        os.use { it.write(bytes) }
        cv.clear()
        cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
        contentResolver.update(uri, cv, null, null)
        return uri
    }

    private fun setThumb(uri: Uri) {
        exec.execute {
            try {
                val b = contentResolver.loadThumbnail(uri, Size(160, 160), null)
                runOnUiThread { thumb.setImageBitmap(b) }
            } catch (e: Exception) { }
        }
    }

    private fun afterSaved(uri: Uri, name: String) {
        toast("Original saved")
        setThumb(uri)
        if (!aiOn) return
        aiBtn.text = "AI …"
        exec.execute {
            val out = try { AiColor.processFile(contentResolver, uri, name) } catch (e: Throwable) { null }
            runOnUiThread {
                aiBtn.text = if (aiOn) "AI ✓" else "AI ✕"
                if (out != null) { setThumb(out); toast("AI Color copy saved (_AI)") }
                else toast("AI Color failed; the original is safe", true)
            }
        }
    }

    // ---------------------------------------------------------------- Video
    private fun mmss(nanos: Long): String {
        val s = nanos / 1_000_000_000L
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun toggleRecord() {
        val r = recording
        if (r != null) { r.stop(); return }
        val vc = videoCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AETHER_${stamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/AetherCamera")
        }
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pending = vc.output.prepareRecording(this, out)
        if (micOn && hasPerm(Manifest.permission.RECORD_AUDIO)) pending = pending.withAudioEnabled()
        try {
            recording = pending.start(ContextCompat.getMainExecutor(this)) { ev ->
                when (ev) {
                    is VideoRecordEvent.Start -> { shutterInner.animate().scaleX(0.55f).scaleY(0.55f).setDuration(150).start() }
                    is VideoRecordEvent.Status -> { statusLabel.text = "● ${mmss(ev.recordingStats.recordedDurationNanos)}" }
                    is VideoRecordEvent.Finalize -> {
                        shutterInner.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
                        recording = null
                        onFinalize(ev)
                        updateStatus()
                    }
                    else -> { }
                }
            }
        } catch (e: Exception) {
            recording = null
            toast("Couldn't start recording: ${e.message}", true)
        }
    }

    private fun onFinalize(ev: VideoRecordEvent.Finalize) {
        if (ev.hasError()) {
            when (ev.error) {
                VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA -> toast("Recording too short; nothing was saved", true)
                VideoRecordEvent.Finalize.ERROR_INSUFFICIENT_STORAGE -> toast("Storage is full; the video may be incomplete", true)
                else -> toast("Recording error (${ev.error}); part of the video may not be saved", true)
            }
            return
        }
        val uri = ev.outputResults.outputUri
        setThumb(uri)
        var info = ""
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val fc = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toLongOrNull()
            val f = if (fc != null && dur > 0) fc * 1000.0 / dur else 0.0
            if (dur > 0) info = "Saved ${w}x$h · ~${f1(f)} fps · ${dur / 1000}s"
        } catch (e: Exception) {
            info = ""
        } finally {
            r.release()
        }
        toast(if (info.isNotEmpty()) info else "Saved, but the playback check failed", true)
    }
}
